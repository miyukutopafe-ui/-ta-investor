# TA Investor — iPhone PWA版

この版は **Mac不要** です。
iPhoneのSafariから使い、ホーム画面に追加するとアプリのように起動できます。

## できること

- ウォッチリスト
- Twelve Dataの日足OHLCV取得
- MA20 / MA50 / MA200
- RCI9 / RCI26
- MACD
- 出来高
- ATR
- TA総合スコア 0〜100
- 指値① / 指値②
- 利確① / 利確②
- 損切り
- Regular Bullish / Bearish Divergence
- Hidden Bullish / Bearish Divergence
- RCI9 / RCI26 / MACD Histogram のダイバージェンス一致判定
- ダイバージェンス強度0〜100
- ローソク足チャート
- MA・売買ライン・ダイバージェンス線の表示
- APIキー / ウォッチリスト / 取得済みデータをiPhone内に保存

---

# iPhoneだけで使い始める方法

PWAはSafariからHTTPSで開く必要があります。
「ファイル」アプリ内のHTMLを直接開くだけでは、ホーム画面アプリとして正常動作しません。

一番簡単なのは、これら4ファイルを無料の静的Webホスティングに置く方法です。

必要ファイル:
- index.html
- manifest.webmanifest
- service-worker.js
- icon-180.png
- icon-512.png

## ホスティング後

1. iPhoneのSafariで公開URLを開く
2. 共有ボタンをタップ
3. 「ホーム画面に追加」
4. ホーム画面の TA Investor を起動
5. 右上の⚙︎
6. Twelve Data API keyを入力
7. ↻で更新

---

# Twelve Data

API:
https://api.twelvedata.com/time_series

取得設定:
- interval = 1day
- outputsize = 260
- order = ASC
- timezone = America/New_York

APIキーはHTMLソースには保存せず、
SafariのlocalStorageへ保存する仕様です。

---

# 注意

このMVPのTAスコアや指値・利確・損切り値は、
現時点ではルールベースの仮説です。

実売買の正解を保証するものではありません。
今後、履歴保存・バックテストで重みと閾値を検証して改善する前提です。
